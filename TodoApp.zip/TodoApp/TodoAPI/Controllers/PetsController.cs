﻿using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Threading.Tasks;
using PetsApi.DataAccess;
using PetsApi.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PetsApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PetsController : ControllerBase
    {
        private readonly IPetData _data;
        private readonly ILogger<PetsController> _logger;
        private readonly int userId;

        public PetsController(IPetData data, ILogger<PetsController> logger)
        {
            _data = data;
            _logger = logger;
        }

        private int GetUserId()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            return int.Parse(userId);
        }

        // GET: api/<TodosController>
        [HttpGet]
        public async Task<ActionResult<List<PetModel>>> Get()
        {
            _logger.LogInformation("GET:/api/Todos");
            try
            {
                var res = await _data.GetAllAssigned(GetUserId());
                return Ok(res);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "The GET call to api/Todos failed.");
                return BadRequest();
            }
        }

       /* // GET api/<TodosController>/5
        [HttpGet("{todoId}")]
        public async Task<ActionResult<PetModel>> Get(int todoId)
        {
            _logger.LogInformation("GET:/api/Todos/{TodoId}",todoId);
            try
            {
                var res = await _data.GetOneAssigned(GetUserId(), todoId);
                return Ok(res);
            }
            catch (Exception e)
            {
                _logger.LogError(e,
                    "The GET call to {ApiPath} failed. The Id was {TodoId}",
                    "api/Todos/Id",todoId);
                return BadRequest();
            }
        }

        // POST api/<TodosController>
        [HttpPost]
        public async Task<ActionResult<PetModel>> Post([FromBody] string task)
        {
            _logger.LogInformation("POST:/api/Todos");
            try
            {
                var res = await _data.Create(GetUserId(), task);
                return Ok(res);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "The POST call to api/Todos failed. The task was {Task}",
                    task);
                return BadRequest();
            }
        }

        // PUT api/<TodosController>/5
        [HttpPut("{todoId}")]
        public async Task<IActionResult> Put(int todoId, [FromBody] string task)
        {
            _logger.LogInformation("PUT:/api/Todos/{TodoId} (Task: {Task})",todoId,task);
            try
            {
                await _data.UpdateTask(GetUserId(), todoId, task);

                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,"The PUT call to api/Todos/{TodoId} failed. " +
                    "The task value was {Task}",
                    todoId,task);
                return BadRequest();
            }
        }

        // PUT api/<TodosController>/5
        [HttpPut("{todoId}/Complete")]
        public async Task<IActionResult> Complete(int todoId)
        {
            _logger.LogInformation("PUT:/api/Todos/{TodoId}/Complete",todoId);
            try
            {
                await _data.CompelteTodo(GetUserId(), todoId);

                return Ok();
            }
            catch (Exception e)
            {
                _logger.LogError(e, "The PUT call to api/Todos/{TodoId}/Complete failed.",
                                       todoId);
                return BadRequest();
            }
        }

        // DELETE api/<TodosController>/5
        [HttpDelete("{todoId}")]
        public async Task<IActionResult> Delete(int todoId)
        {
            try
            {
                await _data.Delete(GetUserId(), todoId);

                return Ok();
            }
            catch (Exception e)
            {
                _logger.LogError(e, "The DELETE call to api/Todos/{TodoId} failed.",
                                                          todoId);
                return BadRequest();
            }
        }*/
    }
}
