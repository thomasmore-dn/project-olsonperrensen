﻿using PetsApi.Models;

namespace PetsApi.DataAccess;

public class PetData : IPetData
{
    private readonly ISqlDataAccess _sql;

    public PetData(ISqlDataAccess sql)
    {
        _sql = sql;
    }

    public Task<List<PetModel>> GetAllAssigned(int userID)
    {
        return _sql.LoadData<PetModel, dynamic>(
            "pets.spPets_GetAllAssigned", new { user_id_param = userID });
    }
/*
    public async Task<PetModel?> GetOneAssigned(int assignedTo, int todoId)
    {
        return (await _sql.LoadData<PetModel, dynamic>(
            "dbo.spTodos_GetOneAssigned", new
            {
                AssignedTo = assignedTo,
                TodoId = todoId
            })).FirstOrDefault();
    }
    public async Task<PetModel?> Create(int assignedTo, string task)
    {
        var res = await _sql.LoadData<PetModel, dynamic>(
            "dbo.spTodos_Create", new
            {
                AssignedTo = assignedTo,
                Task = task
            });

        return res.FirstOrDefault();
    }
    public Task UpdateTask(int assignedTo, int todoId, string task)
    {
        return _sql.SaveData<dynamic>(
            "dbo.spTodos_UpdateTask",
            new
            {
                AssignedTo = assignedTo,
                TodoId = todoId,
                Task = task
            });
    }

    public Task CompelteTodo(int assignedTo, int todoId)
    {
        return _sql.SaveData<dynamic>(
            "dbo.spTodos_CompleteTodo",
            new
            {
                AssignedTo = assignedTo,
                TodoId = todoId
            });
    }
    public Task Delete(int assignedTo, int todoId)
    {
        return _sql.SaveData<dynamic>(
            "dbo.spTodos_Delete",
            new
            {
                AssignedTo = assignedTo,
                TodoId = todoId
            });
    }*/
}
