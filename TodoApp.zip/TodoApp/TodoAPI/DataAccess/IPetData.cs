﻿using PetsApi.Models;

namespace PetsApi.DataAccess
{
    public interface IPetData
    {
/*        Task CompelteTodo(int assignedTo, int todoId);
        Task<PetModel?> Create(int assignedTo, string task);
        Task Delete(int assignedTo, int todoId);*/
        Task<List<PetModel>> GetAllAssigned(int assignedTo);
/*        Task<PetModel?> GetOneAssigned(int assignedTo, int todoId);
        Task UpdateTask(int assignedTo, int todoId, string task);*/
    }
}