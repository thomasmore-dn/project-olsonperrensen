﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PetsApi.Models;

public class PetModel
{
    public int pet_id { get; set; }

    public int owner_id { get; set; }

    public int breed_id { get; set; }
    
    public string? Name { get; set; }

    public string? gender { get; set; }

    public int age { get; set; }
    public string? size { get; set; }

    public string? color { get; set; }

    public string? story { get; set; }
    public string? diet { get; set; }
    public string? register_date { get; set; }
    public string? healthcare_id { get; set; }
    public bool? online_purchased { get; set; }
}
